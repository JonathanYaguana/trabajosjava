package archivos;

import java.util.Scanner;
import java.io.*;

public class Archivos {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String strUsuario;
        String strPassword;

        String strCadena;
        String strUser;
        String strPass;
        String strLinea;

        int intIndice;
        int intOpcion;

        boolean boolExiste = false;
        boolean boolBan1 = true;
        boolean boolBan2 = true;

        Menu objMenu = new Menu();

        File archivo = null;
        FileReader fr = null;
        BufferedReader br = null;

        while (boolExiste == false) {
            System.out.println("Bienvenidos al sistema \n");
            System.out.println("Ingrese usuario");
            strUsuario = sc.next();
            System.out.println("Ingrese contraseña");
            strPassword = sc.next();

            try {
                archivo = new File("C:\\archivos\\usuario.txt");

                fr = new FileReader(archivo);

                br = new BufferedReader(fr);

                while ((strCadena = br.readLine()) != null) {

                    strCadena = strCadena.substring(1);

                    intIndice = strCadena.indexOf('*');

                    strUser = strCadena.substring(0, intIndice);

                    strPass = strCadena.substring(intIndice + 1);

                    strPass = strPass.replace('*', ' ');

                    strPass = strPass.trim();

                    if ((strUsuario.equals(strUser)) && (strPassword.equals(strPass))) {
                        boolExiste = true;

                        while (boolBan1) {

                            intOpcion = objMenu.mostrarMenu();

                            switch (intOpcion) {
                                case 1:
                                    while (boolBan2) {

                                        intOpcion = objMenu.mostrarUsuario();

                                        switch (intOpcion) {
                                            case 1:

                                                break;
                                            case 2:

                                                break;
                                            case 3:

                                                break;
                                            case 4:
                                                System.out.println("\nLista de Usuarios y su contraseña\n");
                                                File f = new File("C:\\archivos\\usuario.txt");

                                                Scanner s;
                                                Scanner s1;

                                                try {
                                                    s = new Scanner(f);

                                                    while (s.hasNextLine()) {
                                                        strLinea = s.nextLine();

                                                        s1 = new Scanner(strLinea);

                                                        s1.useDelimiter("\\Q*\\E");
                                                        System.out.println("El usuario es: " + s1.next() + " -Su clave es: " + s1.next() + "\n");

                                                    }

                                                } catch (IOException ex) {
                                                }

                                                break;
                                            case 5:
                                                boolBan1 = false;
                                                boolBan2 = false;
                                                break;
                                            default:
                                                System.out.println("Opcion no valida");
                                        }
                                    }
                           

                                    break;
                                case 2:
                                    while (boolBan2) {

                                        intOpcion = objMenu.mostrarUsuario();

                                        switch (intOpcion) {
                                            case 1:

                                                break;
                                            case 2:

                                                break;
                                            case 3:

                                                break;
                                            case 4:
                                                System.out.println("\nLista de Estudiantes y su contraseña\n");
                                                archivo = new File("C:\\archivos\\estudiante.txt");

                                                fr = new FileReader(archivo);

                                                br = new BufferedReader(fr);

                                                try {

                                                    while ((strCadena = br.readLine()) != null) {
                                                        strCadena = strCadena.substring(1);

                                                        intIndice = strCadena.indexOf('*');

                                                        strUser = strCadena.substring(0, intIndice);

                                                        strPass = strCadena.substring(intIndice + 1);

                                                        strPass = strPass.replace('*', ' ');

                                                        strPass = strPass.trim();

                                                        System.out.println("El estudiante es: " + strUser + "  -Su contraseña es: " + strPass + "\n");
                                                    }

                                                } catch (IOException ex) {
                                                }

                                                break;
                                            case 5:
                                                boolBan1 = false;
                                                boolBan2 = false;
                                                break;
                                            default:
                                                System.out.println("Opcion no valida");
                                        }
                                    }
                   
                                    break;
                                case 3:
                                    while (boolBan2) {

                                        intOpcion = objMenu.mostrarUsuario();

                                        switch (intOpcion) {
                                            case 1:

                                                break;
                                            case 2:

                                                break;
                                            case 3:

                                                break;
                                            case 4:
                                                System.out.println("\nLista de Doscentes y su contraseña\n");
                                                File f = new File("C:\\archivos\\docente.txt");

                                                Scanner s;
                                                Scanner s1;

                                                try {
                                                    s = new Scanner(f);

                                                    while (s.hasNextLine()) {
                                                        strLinea = s.nextLine();

                                                        s1 = new Scanner(strLinea);

                                                        s1.useDelimiter("\\Q*\\E");
                                                        System.out.println("El docente es: " + s1.next() + " -Su clave es: " + s1.next() + "\n");

                                                    }

                                                } catch (IOException ex) {
                                                }

                                                break;
                                            case 5:
                                                boolBan1 = false;
                                                boolBan2 = false;
                                                break;
                                            default:
                                                System.out.println("Opcion no valida");
                                        }
                                    }
                               
                                    break;
                                case 4:
                                    boolBan1 = false;
                                    break;

                                default:

                                    System.out.println("Opcion no valida"); 
                            }

                        }

                    }

                }
                if (!boolExiste) {
                    System.out.println("\nUsuario no existe\n");
                }

            } catch (IOException ex) {

                ex.printStackTrace();

            } finally {

                if (null != fr) {

                }

            }
        }
    }
}
