package archivos;

import java.util.Scanner;

public class Menu {
    Scanner sc = new Scanner(System.in);
    public int mostrarMenu() {
        int intOpcion;
        System.out.println("\n1. Administrar Usuario");
        System.out.println("2. Administrar Estudiantes");
        System.out.println("3. Administrar Docentes");
        System.out.println("4. Salir");
        intOpcion = sc.nextInt();
        return intOpcion;
    }

    public int mostrarUsuario() {
        int intOpcion;
        System.out.println("\n1. Ingresar Usuario");
        System.out.println("2. Modificar Usuario");
        System.out.println("3. Eliminar usuario");
        System.out.println("4. Mostrar usuario");
        System.out.println("5. Salir");
        intOpcion = sc.nextInt();
        return intOpcion;
    }
}
